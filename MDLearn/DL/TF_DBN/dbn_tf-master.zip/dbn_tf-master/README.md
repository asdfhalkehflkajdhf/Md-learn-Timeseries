# Usage
See [example file](./test.py).
# Tags
See release page.
# Further
See [question](http://stackoverflow.com/questions/35622434/custom-operation-implementation-for-rbm-dbn-with-tensorflow)
# Contact Info
mailto: my id at gmail.com
